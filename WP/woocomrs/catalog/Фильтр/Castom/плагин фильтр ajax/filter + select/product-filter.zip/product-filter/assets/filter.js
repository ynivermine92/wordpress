document.addEventListener('DOMContentLoaded', () => {


    const form = document.getElementById('product-filter-form');
    const results = document.getElementById('filter-results');
    const sortSelect = document.querySelector('.selector__wrapper');

    if (!form || !results) return;

    const filterProducts = () => {

        const data = new FormData();
        data.append('action', 'filter_products');

        form.querySelectorAll('input[type="checkbox"]:checked').forEach(input => {

            data.append(input.name, input.value);
        });


        const min = form.querySelector('#lower').value;
        const max = form.querySelector('#upper').value;
        data.append('min_price', min);
        data.append('max_price', max);

        // Сортировка
        if (sortSelect) data.append('orderby', sortSelect.value);


        results.innerHTML = `
                <div class="sk-circle">
                <div class="sk-circle1 sk-child"></div>
                <div class="sk-circle2 sk-child"></div>
                <div class="sk-circle3 sk-child"></div>
                <div class="sk-circle4 sk-child"></div>
                <div class="sk-circle5 sk-child"></div>
                <div class="sk-circle6 sk-child"></div>
                <div class="sk-circle7 sk-child"></div>
                <div class="sk-circle8 sk-child"></div>
                <div class="sk-circle9 sk-child"></div>
                <div class="sk-circle10 sk-child"></div>
                <div class="sk-circle11 sk-child"></div>
                <div class="sk-circle12 sk-child"></div>
                </div>
                `;




        fetch(filter_ajax.ajaxurl, {
            method: 'POST',
            body: data
        })
            .then(res => res.text())
            .then(html => {
                results.innerHTML = html;
            })
            .catch(err => {
                console.error(err);
                results.innerHTML = 'Произошла ошибка';
            });
    };


    form.querySelectorAll('input').forEach(input => {
        input.addEventListener('change', filterProducts);
    });


    if (sortSelect) sortSelect.addEventListener('change', filterProducts);

    filterProducts()

});





