<?php

/**
 * Plugin Name: WooCommerce AJAX Universal Filter
 * Description: AJAX фильтр товаров WooCommerce по всем атрибутам и цене
 * Version: 1.0
 * Author: Maksim
 */


if (!defined('ABSPATH')) exit;

// Подключение JS
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script(
        'woo-filter-js',
        plugin_dir_url(__FILE__) . 'assets/filter.js',
        ['jquery'],
        null,
        true
    );

    wp_localize_script('woo-filter-js', 'filter_ajax', [
        'ajaxurl' => admin_url('admin-ajax.php')
    ]);
});


// Шорткод для вывода фильтра  (функция)
add_shortcode('woo_ajax_filter', function ($atts) {
    ob_start();

    $attribute_taxonomies = wc_get_attribute_taxonomies();

    if ($attribute_taxonomies) :




?>

        <div class="categories__box">
            <!--  selector -->
            <div class="selector">
                <form class="woocommerce-ordering" method="get">
                    <div class="categories__box">

                        <div class="selector__box">
                            <div class="selector__inner">
                                <select name="orderby" class="selector__wrapper">
                                    <option value="menu_order">Сортувати</option>
                                    <option value="popularity">За популярністю</option>
                                    <option value="rating">За рейтингом</option>
                                    <option value="date">Новинки</option>
                                    <option value="price">Від дешевих до дорогих</option>
                                    <option value="price-desc">Від дорогих до дешевих</option>

                                </select>
                            </div>
                        </div>

                    </div>
                    <input type="hidden" name="paged" value="1">
                </form>
            </div>
            <!--   selector -->
        </div>



        <div class="categories__wrapper">
            <div id="product-filter-form" class="filter">
                <div class="filter__wrapper">
                    <?  // Цикл по всем атрибутам
                    foreach ($attribute_taxonomies as $tax) :

                        // Правильное имя таксономии через WooCommerce
                        $taxonomy = wc_attribute_taxonomy_name($tax->attribute_name);

                        $terms = get_terms([
                            'taxonomy'   => $taxonomy,
                            'hide_empty' => true,
                        ]);

                        if (!empty($terms) && !is_wp_error($terms)) : ?>
                            <div class="filter__item filter__item-<?php echo esc_attr($tax->attribute_id); ?>">
                                <h3><?php echo esc_html($tax->attribute_label); ?></h3>
                                <?php foreach ($terms as $term) : ?>
                                    <label>
                                        <input type="checkbox"
                                            name="attributes[<?php echo esc_attr($tax->attribute_name); ?>][]"
                                            value="<?php echo esc_attr($term->term_id); ?>">
                                        <?php echo esc_html($term->name); ?>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                    <?php
                        endif;
                    endforeach;
                    ?>



                    <!-- Фильтр по цене -->
                    <?
                    global $wpdb;


                    // минимальная и максимальная цена из всех опубликованных товаров тут нужно получить цену минамальную максимальную
                    $min_price = floor($wpdb->get_var("SELECT MIN(meta_value+0) FROM {$wpdb->postmeta} WHERE meta_key = '_price'"));
                    $max_price = ceil($wpdb->get_var("SELECT MAX(meta_value+0) FROM {$wpdb->postmeta} WHERE meta_key = '_price'"));
                    ?>

                    <div class="filter__item filter-price">

                        <h3 class="filter__title">ЦіНА</h3>
                        <div class="fitler-price__form">
                            <div class="wrapper">
                                <fieldset class="filter-price">
                                    <div class="price-field">
                                        <div class="slider-track"></div>
                                        <input
                                            type="range"
                                            min="<?php echo $min_price; ?>"
                                            max="<?php echo $max_price; ?>"
                                            value="<?php echo $min_price; ?>"
                                            id="lower"
                                            name="min_price" />
                                        <input
                                            type="range"
                                            min="<?php echo $min_price; ?>"
                                            max="<?php echo $max_price; ?>"
                                            value="<?php echo $max_price; ?>"
                                            id="upper"
                                            name="max_price" />
                                    </div>
                                </fieldset>
                            </div>
                            <div class="price__box">
                                ЦіНА :
                                <div class="price__wrapper">
                                    <span class="price"><?php echo $min_price; ?></span>
                                    <span class="price__currency">Грн</span>
                                </div>
                                <div class="price__wrapper">
                                    <span class="price__max"><?php echo $max_price; ?></span>
                                    <span class="price__currency">Грн</span>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>

            <div class="categories__content" id="filter-results">


                <!-- Шаблоный вывод товаром  адапитрованый под моии стили и  размер картинки  (вывод до аякса товара)-->

                <?php if (wc_get_loop_prop('total')) : ?>
                    <div class="categories__items">
                        <?php while (have_posts()) : the_post();
                            $product = wc_get_product(get_the_ID());
                            $img_url = get_the_post_thumbnail_url(get_the_ID(), 'custom_335');
                            if (!$img_url) {
                                $img_url = get_the_post_thumbnail_url(get_the_ID(), 'medium');
                            }
                        ?>
                            <div class="categories__item">
                                <a class="categories__cart" href="<?php the_permalink(); ?>">
                                    <?php if ($product && $product->is_on_sale()) : ?>
                                        <span class="categories__sale"><span>SALE</span></span>
                                    <?php endif; ?>

                                    <img src="<?= esc_url($img_url); ?>" alt="<?= esc_attr(get_the_title()); ?>" />

                                    <span class="categories__name"><?= get_the_title(); ?></span>
                                    <?php if ($product) : ?>
                                        <span class="categories__price"><?= $product->get_price_html(); ?></span>
                                    <?php endif; ?>
                                </a>

                                <a class="categories__link" href="<?= esc_url(add_query_arg('add-to-cart', $product->get_id(), wc_get_cart_url())); ?>">В КОШИК</a>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php endif; ?>
                <!--  -->




            </div>
        </div>
        <?php endif;

    return ob_get_clean();
});








add_action('wp_ajax_filter_products', 'woo_filter_products_callback');
add_action('wp_ajax_nopriv_filter_products', 'woo_filter_products_callback');

function woo_filter_products_callback()
{
    
    // Получаем выбранную сортировку
    $orderby = isset($_POST['orderby']) ? sanitize_text_field($_POST['orderby']) : 'menu_order';

    // Базовые аргументы WP_Query
    $args = [
        'post_type' => 'product',
        'posts_per_page' => -1,
        'tax_query' => [],
        'meta_query' => [],
    ];

    // Фильтр по атрибутам
    $tax_query = ['relation' => 'AND'];
    if (!empty($_POST['attributes']) && is_array($_POST['attributes'])) {
        foreach ($_POST['attributes'] as $attr => $terms) {
            $term_ids = array_map('intval', $terms);
            if ($term_ids) {
                $tax_query[] = [
                    'taxonomy' => 'pa_' . $attr,
                    'field'    => 'term_id',
                    'terms'    => $term_ids,
                    'operator' => 'IN',
                ];
            }
        }
    }
    if (count($tax_query) > 1) $args['tax_query'] = $tax_query;








    // Фильтр по цене
    $meta_query = ['relation' => 'AND'];
    if (!empty($_POST['min_price'])) {
        $meta_query[] = [
            'key' => '_price',
            'value' => floatval($_POST['min_price']),
            'compare' => '>=',
            'type' => 'NUMERIC',
        ];
    }
    if (!empty($_POST['max_price'])) {
        $meta_query[] = [
            'key' => '_price',
            'value' => floatval($_POST['max_price']),
            'compare' => '<=',
            'type' => 'NUMERIC',
        ];
    }
    if (count($meta_query) > 1) {
        $args['meta_query'] = $meta_query;
    }

    // Обработка сортировки select
    switch ($orderby) {
        case 'popularity':
            $args['meta_key'] = 'total_sales';
            $args['orderby'] = 'meta_value_num';
            $args['order'] = 'DESC';
            break;
        case 'rating':
            $args['meta_key'] = '_wc_average_rating';
            $args['orderby'] = 'meta_value_num';
            $args['order'] = 'DESC';
            break;
        case 'date':
            $args['orderby'] = 'date';
            $args['order'] = 'DESC';
            break;
        case 'price':
            $args['meta_key'] = '_price';
            $args['orderby'] = 'meta_value_num';
            $args['order'] = 'ASC';
            break;
        case 'price-desc':
            $args['meta_key'] = '_price';
            $args['orderby'] = 'meta_value_num';
            $args['order'] = 'DESC';
            break;
        default:
            $args['orderby'] = 'menu_order';
            $args['order'] = 'ASC';
            break;
    }

    // WP_Query
    $query = new WP_Query($args);

    if ($query->have_posts()) {
        echo '<ul class="categories__items">';
        while ($query->have_posts()) {
            $query->the_post();
            $product = wc_get_product(get_the_ID());
        ?>
            <li class="categories__item">
                <a class="categories__cart" href="<?= get_permalink(); ?>">
                    <?php if ($product && $product->is_on_sale()) : ?>
                        <span class="categories__sale"><span>SALE</span></span>
                    <?php endif; ?>

                    <?php if (has_post_thumbnail()) :
                        $img_url = get_the_post_thumbnail_url(get_the_ID(), 'custom_335');
                        if (!$img_url) {
                            // Если кастомная миниатюра не создана, используем medium
                            $img_url = get_the_post_thumbnail_url(get_the_ID(), 'medium');
                        }
                    ?>
                        <img src="<?= esc_url($img_url); ?>" alt="<?= esc_attr(get_the_title()); ?>" />
                    <?php endif; ?>



                    <span class="categories__name"><?= get_the_title(); ?></span>

                    <?php if ($product) : ?>
                        <span class="categories__price"><?= $product->get_price_html(); ?></span>
                    <?php endif; ?>
                </a>

                <a class="categories__link" href="<?= esc_url(add_query_arg('add-to-cart', $product->get_id(), wc_get_cart_url())); ?>">В КОШИК</a>
            </li>
<?php
        }
        echo '</ul>';
    } else {
        echo '<p>ТАКОГО ТОВАРА НЕМАЄ</p>';
    }

    wp_reset_postdata();
    wp_die();
}
