<?php

/**
 * Plugin Name: WooCommerce AJAX Universal Filter
 * Description: AJAX фильтр товаров WooCommerce по всем атрибутам и цене
 * Version: 1.0
 * Author: maksim
 */

if (!defined('ABSPATH')) exit;

// Подключение JS
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script(
        'woo-filter-js',
        plugin_dir_url(__FILE__) . 'assets/filter.js',
        ['jquery'],
        null,
        true
    );

    wp_localize_script('woo-filter-js', 'filter_ajax', [
        'ajaxurl' => admin_url('admin-ajax.php')
    ]);
});

// Шорткод для вывода фильтра
add_shortcode('woo_ajax_filter', function ($atts) {
    ob_start();

    $attribute_taxonomies = wc_get_attribute_taxonomies();

    if ($attribute_taxonomies) :
        echo '<form id="product-filter-form">';

        // Цикл по всем атрибутам
        foreach ($attribute_taxonomies as $tax) :
            $taxonomy = 'pa_' . $tax->attribute_name;
            $terms = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => true]);

            if (!empty($terms) && !is_wp_error($terms)) : ?>
                <div class="filter__item filter__item-<?= $tax->attribute_id; ?>">

                    <h4><?= esc_html($tax->attribute_label); ?></h4>
                    <?php foreach ($terms as $term) : ?>
                        <label>
                            <input type="checkbox" name="attributes[<?= esc_attr($tax->attribute_name); ?>][]" value="<?= esc_attr($term->term_id); ?>">
                            <?= esc_html($term->name); ?>
                        </label>
                    <?php endforeach; ?>
                </div>
        <?php
            endif;
        endforeach;
        ?>


        <!-- Фильтр по цене -->

        <div class="filter-block">
            <h4>Цена</h4>
            <input type="number" id="filter-min-price" placeholder="Мин. цена">
            <input type="number" id="filter-max-price" placeholder="Макс. цена">
        </div>

        </form>

        <div id="filter-results"></div>
        <?php endif;

    return ob_get_clean();
});








// AJAX обработчик
add_action('wp_ajax_filter_products', 'woo_filter_products_callback');
add_action('wp_ajax_nopriv_filter_products', 'woo_filter_products_callback');

function woo_filter_products_callback()
{
    $args = [
        'post_type' => 'product',
        'posts_per_page' => -1,
        'tax_query' => [],
        'meta_query' => [],
    ];

    // Фильтруем по атрибутам
    $tax_query = ['relation' => 'AND'];
    if (!empty($_POST['attributes']) && is_array($_POST['attributes'])) {
        foreach ($_POST['attributes'] as $attr => $terms) {
            $term_ids = array_map('intval', $terms);
            if ($term_ids) {
                $tax_query[] = [
                    'taxonomy' => 'pa_' . $attr,
                    'field'    => 'term_id',
                    'terms'    => $term_ids,
                    'operator' => 'IN',
                ];
            }
        }
    }
    if (count($tax_query) > 1) $args['tax_query'] = $tax_query;

    // Фильтр по цене
    $meta_query = ['relation' => 'AND'];
    if (!empty($_POST['min_price'])) $meta_query[] = [
        'key' => '_price',
        'value' => floatval($_POST['min_price']),
        'compare' => '>=',
        'type' => 'NUMERIC'
    ];
    if (!empty($_POST['max_price'])) $meta_query[] = [
        'key' => '_price',
        'value' => floatval($_POST['max_price']),
        'compare' => '<=',
        'type' => 'NUMERIC'
    ];
    if (count($meta_query) > 1) $args['meta_query'] = $meta_query;

    // Запрос товаров
    $query = new WP_Query($args);

    if ($query->have_posts()) {
        echo '<ul class="categories__items">';
        while ($query->have_posts()) {
            $query->the_post();
            $product = wc_get_product(get_the_ID());
        ?>
            <li class="categories__item">
                <a class="categories__cart" href="<?= get_permalink(); ?>">
                    <?php if (has_post_thumbnail()) : ?>
                        <img src="<?= get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>" alt="<?= get_the_title(); ?>" />
                    <?php endif; ?>
                    <span class="categories__name"><?= get_the_title(); ?></span>
                    <?php if ($product) : ?>
                        <span class="categories__price"><?= $product->get_price_html(); ?></span>
                    <?php endif; ?>
                </a>
                <a class="categories__link" href="#">В КОШИК</a>
            </li>
<?
        }
        echo '</ul>';
    } else {
        echo '<p>Товары не найдены</p>';
    }

    wp_reset_postdata();
    wp_die();
}
