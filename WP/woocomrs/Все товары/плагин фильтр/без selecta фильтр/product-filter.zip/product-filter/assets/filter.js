document.addEventListener('DOMContentLoaded', function () {
    function filterProducts() {
        let form = document.getElementById('product-filter-form');
        let data = new FormData();
        data.append('action', 'filter_products');

        // Сбор чекбоксов атрибутов
        let attributes = form.querySelectorAll('input[type="checkbox"]:checked');
        attributes.forEach(function (input) {
            data.append(input.name, input.value);
        });

        // Цена
        let minPrice = form.querySelector('#filter-min-price').value;
        let maxPrice = form.querySelector('#filter-max-price').value;
        if (minPrice) data.append('min_price', minPrice);
        if (maxPrice) data.append('max_price', maxPrice);

        // Показываем загрузку
        document.getElementById('filter-results').innerHTML = 'Загрузка...';

        fetch(filter_ajax.ajaxurl, {
            method: 'POST',
            body: data
        })
            .then(response => response.text())
            .then(html => {
                document.getElementById('filter-results').innerHTML = html;
            })
            .catch(err => {
                console.error(err);
                document.getElementById('filter-results').innerHTML = 'Произошла ошибка';
            });
    }

    // Вешаем обработчик на все input
    let form = document.getElementById('product-filter-form');
    if (form) {
        let inputs = form.querySelectorAll('input');
        inputs.forEach(function (input) {
            input.addEventListener('change', filterProducts);
        });
    }
    filterProducts();
});
